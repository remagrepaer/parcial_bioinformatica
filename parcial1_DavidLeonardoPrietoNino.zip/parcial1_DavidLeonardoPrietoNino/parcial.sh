#!/bin/bash
#SBATCH -p normal
#SBATCH -N 1
#SBATCH -n 10
#SBATCH -t 0-00:20
#SBATCH -o salida.out
#SBATCH -e error.err
#SBATCH --mail-user=davidl.prieto@urosario.edu.co
#SBATCH --mail-type=ALL

salloc
module load muscle/3.8.31
muscle -in pun2.fasta -out alineamiento.fasta
